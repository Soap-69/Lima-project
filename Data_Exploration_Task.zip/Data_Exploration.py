import pandas as pd
import matplotlib.pyplot as plt
import scipy.stats

# Function to save numeric stats
def save_numeric_stats(data, filename):
    numeric_data = data.select_dtypes(include=['number', 'bool'])
    numeric_stats = numeric_data.aggregate(['mean', 'std', 'skew', 'kurt']).transpose().reset_index()
    numeric_stats.columns = ['variable', 'mean', 'std', 'skew', 'kurt']
    numeric_stats.to_csv(filename, index=False)

# Load and merge the data
questions = pd.read_csv("askUbuntu-questions.csv", thousands=',', parse_dates=['Question_Post_Time'])
answers = pd.read_csv("askUbuntu-answers.csv", thousands=',', parse_dates=['Question_ID'])
questions['question_id'] = questions['Question_ID'].astype(str)
answers['question_id'] = answers['Question_ID'].astype(str)
merged_data = questions.merge(answers, left_on='question_id', right_on='question_id', suffixes=('_question', '_answer'))

# Save numeric stats for the entire dataset
save_numeric_stats(merged_data, "numeric_stats.csv")

# Save numeric stats for different subsets of the data
filters = {'closed': ~merged_data['Question_Closed'], 'not_closed': ~merged_data['Question_Closed'], 'edited': merged_data['Edited'], 'not_edited': ~merged_data['Edited']}
for key, value in filters.items():
    save_numeric_stats(merged_data[value], f"numeric_stats_{key}.csv")

# Create and save plots
merged_data.resample('D', on='Question_Post_Time').size().plot().get_figure().savefig("daily_posts.png")
merged_data.plot.scatter(x='Question_Score', y='Answer_Score').get_figure().savefig("scatter_plot_scores.png")
merged_data[['Question_Score', 'Answer_Score']].plot.hist(alpha=0.5, bins=20).get_figure().savefig("score_histograms.png")

# Calculate the correlation and p-value
correlation, p_value = scipy.stats.pearsonr(merged_data['Question_Score'], merged_data['Answer_Score'])
print(f"Correlation: {correlation}\nP-value: {p_value}\nSignificance: {p_value < 0.05}")

# Find the two most negatively and positively correlated variables
correlation_matrix = merged_data.corr().unstack().sort_values(kind="quicksort", key=abs)
print(correlation_matrix[correlation_matrix != 1].drop_duplicates().tail(2))
print(correlation_matrix[correlation_matrix != 1].drop_duplicates().head(2))
